Info decorators
===============

Useful when you want to show information to specific region. For example, there is "Goa" decorator
for drivers in Goa, India. It just sends drivers a link to the text post on Telegra.ph. This post
explains how to behave to avoid conflicts with local agressive taxi unions.

Telegra.ph is used because it has "Instant View" on mobile and looks friendly. If you want to create
your own post, use @telegraph bot: your posts will be linked to your Telegram account and you will
be able to edit them in the future.

You can add as many decorators as you want. Be sure you wired these decorators at `routes.js`.
