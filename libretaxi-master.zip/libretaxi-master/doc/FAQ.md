# LibreTaxi FAQ

#### Q: I bought a Xiaomi Mi5 in China. I don't have Google Play Store or services. I downloaded Telegram APK from ApkMirror. But the app won't install. I get an error due to Google Play Services. How do I solve this?
A: Telegram needs Google Play Services. But you can use [The Open Gapps](http://opengapps.org/) install this dependency. Also see [about](http://opengapps.org/#aboutsection).
